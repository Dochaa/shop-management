import 'dart:io';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:wellios/color.dart';
import 'package:wellios/image_helper.dart';
import 'package:wellios/model/wellgive/wellgive_employee_entity.dart';
import 'package:wellios/service/service.dart' as service;

import '../../../app_constants.dart';
import '../../../main.dart';
import '../../../model/wellgive/wellgive_hashtag_entity.dart';
import '../../wellplace/wellplace.dart';
import '../common.dart';
import '../component/wellgive_gift_message.dart';
import '../component/wellgive_hashtags.dart';
import '../component/wellgive_point_selector.dart';
import '../component/wellgive_user_section.dart';
import 'screen_wellgive_employee.dart';
import 'screen_wellgive_revise.dart';

final listEmpEntity = StateProvider<List<WellGiveEmployeeEntity>>((ref) => []);

class ScreenWellGiveTransfer extends ConsumerStatefulWidget {
  const ScreenWellGiveTransfer({
    Key? key,
  }) : super(key: key);

  @override
  ConsumerState createState() => _ScreenWellGiveTransferState();
}

class _ScreenWellGiveTransferState extends ConsumerState<ScreenWellGiveTransfer>
    with SingleTickerProviderStateMixin {
  final _numberFormat = NumberFormat();

  var _point = 0;
  var _msg = '';
  String showName = 'Emp';
  WellGiveHashTagEntity? _hashtag;
  WellGiveEmployeeEntity? _recipient = null;

  final _shouldShowHashTagNotSelectedProvider =
      StateProvider.autoDispose<bool>((ref) => false);
  AnimationController? controller;
  @override
  void initState() {
    controller = AnimationController(
        duration: const Duration(milliseconds: 500), vsync: this);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final userConfig = ref.watch(wellGiveConfigProvider);
    final Animation<double> offsetAnimation = Tween(begin: 0.0, end: 24.0)
        .chain(CurveTween(curve: Curves.elasticIn))
        .animate(controller!)
      ..addStatusListener((status) {
        if (status == AnimationStatus.completed) {
          controller!.reverse();
        }
      });
    return GestureDetector(
      onTap: () {
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Container(
        color: wellGiveBackgroundColor,
        child: Padding(
          padding: const EdgeInsets.only(
            top: wellGiveMenuHeight,
          ),
          child: Column(
            children: [
              Consumer(
                builder: (context, ref, child) {
                  final user = ref.watch(userProvider);
                  if (user == null) return const SizedBox();
                  final coins = ref.watch(backupBalanceProvider);
                  return Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 24,
                      vertical: 12,
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.baseline,
                      textBaseline: TextBaseline.alphabetic,
                      children: [
                        Expanded(
                          child: Text(
                            '${user.firstname} ${user.lastname}'.trim(),
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 24,
                          width: 24,
                          child: Image.asset(
                            'new_coins.png'.tfp(),
                          ),
                        ),
                        const SizedBox(
                          width: 8,
                        ),
                        Text(
                          'app.well_point_back',
                          style: const TextStyle(
                            fontSize: 15,
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                          ),
                        ).tr(args: [_numberFormat.format(coins)]),
                      ],
                    ),
                  );
                },
              ),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const SizedBox(
                        height: 12,
                      ),
                      Image.asset(
                        'mascot_3.png'.tfp(),
                        height: 200,
                      ),
                      const SizedBox(
                        height: 12,
                      ),
                      WellGivePointSelector(
                        onPointChange: (int point) {
                          log('point: $point');
                          _point = point;
                        },
                        minPoint: userConfig.tran_point_min,
                        maxPoint: userConfig.tran_point_max,
                        initialPoint: userConfig.tran_point_min,
                        isWellGive: true,
                      ),
                      const SizedBox(
                        height: 12,
                      ),
                      Container(
                        margin: const EdgeInsets.only(
                          left: 24,
                          right: 24,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: const BorderRadius.all(
                            Radius.circular(
                              8,
                            ),
                          ),
                        ),
                        child: Builder(
                          builder: (context) {
                            final recipient =
                                ref.watch(listEmpEntity.notifier).state;
                            if (recipient.isEmpty) {
                              return InkWell(
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    appPageRoute(ScreenWellGiveEmployee(
                                      showCheckbok: true,
                                      provider: listEmpEntity,
                                      callback:
                                          (WellGiveEmployeeEntity empEntity,
                                              int addAll) {
                                        var userSelect = ref
                                            .read(listEmpEntity.notifier)
                                            .state;
                                        //normal
                                        if (addAll == 0) {
                                          if (userSelect.contains(empEntity)) {
                                            userSelect.remove(empEntity);
                                          } else {
                                            userSelect.add(empEntity);
                                          }
                                          //add all
                                        } else if (addAll == 1) {
                                          userSelect.clear();
                                          userSelect.addAll(ref
                                              .read(wellGiveEmployeesProvider));
                                        } else if (addAll == 2) {
                                          userSelect.clear();
                                        }
                                        setState(() {
                                          showName = userSelect
                                              .map((c) => c.firstname)
                                              .toList()
                                              .join(' , ');
                                        });
                                      },
                                      onUserSelected: (selectedUser) {
                                        setState(() {
                                          log('selectedUser: $selectedUser');
                                          _recipient = selectedUser;
                                        });
                                      },
                                    )),
                                  );
                                },
                                borderRadius: const BorderRadius.all(
                                  Radius.circular(8),
                                ),
                                child: Container(
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: Padding(
                                          padding: const EdgeInsets.only(
                                            left: 16,
                                            top: 10,
                                            bottom: 10,
                                          ),
                                          child: Text(
                                            'app.search',
                                            style: TextStyle(
                                              fontSize: 16,
                                              color: wellGiveFontSecondaryColor,
                                            ),
                                          ).tr(),
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.only(
                                          right: 8,
                                          top: 4,
                                          bottom: 4,
                                        ),
                                        child: Material(
                                          color: Colors.transparent,
                                          borderRadius: const BorderRadius.all(
                                            Radius.circular(8),
                                          ),
                                          child: Container(
                                            width: 42,
                                            height: 42,
                                            alignment: Alignment.center,
                                            child: Image.asset(
                                              'wellgive_user_icon.png'.tfp(),
                                              width: 24,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            } else {
                              return Padding(
                                padding: const EdgeInsets.only(
                                  left: 24,
                                  right: 16,
                                  top: 10,
                                  bottom: 10,
                                ),
                                child: Material(
                                  color: Colors.transparent,
                                  borderRadius: const BorderRadius.all(
                                    Radius.circular(8),
                                  ),
                                  child: InkWell(
                                    onTap: () {
                                      Navigator.push(
                                        context,
                                        appPageRoute(ScreenWellGiveEmployee(
                                          showCheckbok: true,
                                          provider: listEmpEntity,
                                          callback:
                                              (WellGiveEmployeeEntity empEntity,
                                                  int addAll) {
                                            var userSelect = ref
                                                .read(listEmpEntity.notifier)
                                                .state;
                                            //normal
                                            if (addAll == 0) {
                                              if (userSelect
                                                  .contains(empEntity)) {
                                                userSelect.remove(empEntity);
                                              } else {
                                                userSelect.add(empEntity);
                                              }
                                              //add all
                                            } else if (addAll == 1) {
                                              userSelect.clear();
                                              userSelect.addAll(ref.read(
                                                  wellGiveEmployeesProvider));
                                            } else if (addAll == 2) {
                                              userSelect.clear();
                                            }
                                            setState(() {
                                              showName = userSelect
                                                  .map((c) => c.firstname)
                                                  .toList()
                                                  .join(' , ');
                                            });
                                          },
                                          onUserSelected: (selectedUser) {
                                            setState(() {
                                              log('selectedUser: $selectedUser');
                                              _recipient = selectedUser;
                                            });
                                          },
                                        )),
                                      );
                                    },
                                    borderRadius: const BorderRadius.all(
                                      Radius.circular(8),
                                    ),
                                    child: Row(
                                      children: [
                                        Container(
                                          width: 42,
                                          height: 42,
                                          alignment: Alignment.center,
                                          decoration: new BoxDecoration(
                                            color: primaryBlue,
                                            shape: BoxShape.circle,
                                          ),
                                          child: Text(
                                            '${ref.read(listEmpEntity.notifier).state.length}',
                                            style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 18),
                                          ),
                                        ),
                                        SizedBox(
                                          width: 10,
                                        ),
                                        Expanded(
                                          child: Text(
                                            '$showName',
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style:
                                                TextStyle(color: Colors.black),
                                          ),
                                        ),
                                        Container(
                                          width: 42,
                                          height: 42,
                                          alignment: Alignment.center,
                                          child: Icon(
                                            Icons.arrow_forward_ios,
                                            color: const Color(0xFF7C7A7A),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              );
                            }
                          },
                        ),
                      ),
                      const SizedBox(
                        height: 12,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                          left: 24,
                          right: 24,
                        ),
                        child: WellGiveGiftMessage(
                          onMessageUpdate: (String msg) {
                            log('_msg: $msg');
                            _msg = msg;
                          },
                        ),
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      WellGiveHashtags(
                        onHashTagSelected: (hashtag) {
                          log('onHashTagSelected: $hashtag');
                          ref
                              .read(_shouldShowHashTagNotSelectedProvider
                                  .notifier)
                              .state = false;
                          _hashtag = hashtag;
                        },
                      ),
                      const SizedBox(
                        height: 16,
                      ),
                      Consumer(
                        builder: (context, ref, child) {
                          final shouldShowWaring =
                              ref.watch(_shouldShowHashTagNotSelectedProvider);
                          if (shouldShowWaring) {
                            return Padding(
                              padding: const EdgeInsets.only(
                                bottom: 8,
                              ),
                              child: AnimatedBuilder(
                                  animation: offsetAnimation,
                                  builder: (buildContext, child) {
                                    return Container(
                                      margin: EdgeInsets.symmetric(
                                          horizontal: 24.0),
                                      padding: EdgeInsets.only(
                                          left: offsetAnimation.value + 24.0,
                                          right: 24.0 - offsetAnimation.value),
                                      child: Center(
                                        child: Text(
                                          'app.please_select_hashtag',
                                          style: const TextStyle(
                                            color: Color(0xFFFD397A),
                                            fontSize: 14,
                                            fontWeight: FontWeight.w700,
                                          ),
                                        ).tr(),
                                      ),
                                    );
                                  }),
                            );
                          } else {
                            return const SizedBox();
                          }
                        },
                      ),
                      Text(
                        'app.tranfer_wellgive_no_fee',
                        style: const TextStyle(
                          fontSize: 12,
                          color: Color(0xFFBFBFBF),
                        ),
                      ).tr(),
                    ],
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsets.only(
                  left: 24,
                  right: 24,
                  top: 24,
                  bottom: 24 +
                      (Platform.isIOS
                          ? (MediaQuery.of(context).padding.bottom / 2)
                          : 0),
                ),
                child: Material(
                  color: _recipient == null
                      ? const Color(0xFF20214D).withOpacity(0.4)
                      : const Color(0xFF20214D),
                  borderRadius: const BorderRadius.all(
                    Radius.circular(
                      4,
                    ),
                  ),
                  child: InkWell(
                    onTap: _recipient == null
                        ? null
                        : () async {
                            FocusManager.instance.primaryFocus?.unfocus();
                            await Future.delayed(
                                const Duration(milliseconds: 200), () {});
                            final recipient = _recipient;
                            final hashtag = _hashtag;

                            if (recipient == null) return;

                            if (hashtag == null) {
                              ref
                                  .read(_shouldShowHashTagNotSelectedProvider
                                      .notifier)
                                  .state = true;
                              controller!.forward(from: 0.0);
                              return;
                            }

                            final currentPoint =
                                ref.read(backupBalanceProvider);
                            final isPointEnough = currentPoint >= _point;
                            if (!isPointEnough) {
                              showWellGiveFailedDialog2(
                                  context,
                                  'app.wellgive_fail_msg'
                                      .tr(args: [currentPoint.toString()]));
                              return;
                            }

                            try {
                              ref.read(wellGiveLoading.notifier).state = true;

                              final refCode = await service.generateMyQR(
                                codeType: 'ref',
                                recipientUserId: recipient.id,
                              );

                              ref.read(wellGiveLoading.notifier).state = false;

                              Navigator.push(
                                context,
                                appPageRoute(
                                  ScreenWellGiveRevise(
                                    recipient: recipient,
                                    point: _point,
                                    msg: _msg,
                                    hashtag: hashtag,
                                    refCode: refCode,
                                    codeType: 'ref',
                                  ),
                                ),
                              );
                            } catch (e) {
                              ref.read(wellGiveLoading.notifier).state = false;
                              showWellGiveFailedDialog(context, e.toString());
                            }
                          },
                    borderRadius: const BorderRadius.all(
                      Radius.circular(
                        4,
                      ),
                    ),
                    child: Container(
                      height: 52,
                      alignment: Alignment.center,
                      decoration: const BoxDecoration(
                        borderRadius: BorderRadius.all(
                          Radius.circular(
                            4,
                          ),
                        ),
                      ),
                      child: Text(
                        'app.next',
                        style: TextStyle(
                          color: _recipient == null
                              ? wellGiveFontSecondaryColor
                              : Colors.white,
                          fontSize: 18,
                          letterSpacing: 5.2,
                        ),
                      ).tr(),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
