import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:wellios/color.dart';
import 'package:wellios/main.dart';
import 'package:wellios/model/wellgive/wellgive_employee_entity.dart';
import 'package:wellios/screen/wellgive/component/wellgive_user_section.dart';
import 'package:wellios/screen/wellgive/screen/screen_wellgive_transfer.dart';

import '../common.dart';

typedef void DataCallback(WellGiveEmployeeEntity empEntity,
    int addAll); // normal 0 , add all 1 , clear all 2

class ScreenWellGiveEmployee extends ConsumerStatefulWidget {
  final DataCallback callback;
  final StateProvider<List<WellGiveEmployeeEntity>> provider;
  final bool showCheckbok;

  final void Function(WellGiveEmployeeEntity selectedUser) onUserSelected;

  const ScreenWellGiveEmployee({
    Key? key,
    required this.callback,
    required this.provider,
    this.showCheckbok = false,
    required this.onUserSelected,
  }) : super(key: key);

  @override
  ConsumerState createState() => _ScreenWellGiveEmployeeState();
}

class _ScreenWellGiveEmployeeState
    extends ConsumerState<ScreenWellGiveEmployee> {
  final _textController = TextEditingController();
  final _searchQueryProvider = StateProvider.autoDispose<String>((ref) => '');

  final _lineSeparated = Container(
    alignment: Alignment.center,
    child: Container(
      height: 1,
      color: wellGiveFontSecondaryColor.withOpacity(0.4),
    ),
  );

  final _textFieldInputBorder = const OutlineInputBorder(
    borderRadius: BorderRadius.all(
      Radius.circular(
        8,
      ),
    ),
    borderSide: BorderSide(
      color: Colors.transparent,
    ),
  );
  var checkAll = false;
  @override
  void initState() {
    super.initState();
    _textController.addListener(() {
      ref.read(_searchQueryProvider.notifier).state = _textController.text;
    });
  }

  @override
  void dispose() {
    super.dispose();
    _textController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (ref.read(widget.provider).length ==
        ref.read(wellGiveEmployeesProvider).length) {
      checkAll = true;
    }
    setState(() {});
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'app.list_name',
        ).tr(),
      ),
      body: GestureDetector(
        onTap: () {
          FocusManager.instance.primaryFocus?.unfocus();
        },
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 24,
              ),
              alignment: Alignment.center,
              child: Stack(
                children: [
                  TextField(
                    controller: _textController,
                    keyboardType: TextInputType.text,
                    textInputAction: TextInputAction.done,
                    maxLines: 1,
                    maxLength: 100,
                    textAlign: TextAlign.start,
                    cursorColor: primaryPink,
                    style: TextStyle(
                      color: const Color(0xFF7C7A7A),
                      fontWeight: FontWeight.w700,
                    ),
                    onTap: () {
                      _textController.selection = TextSelection.collapsed(
                        offset: _textController.text.length,
                      );
                    },
                    decoration: InputDecoration(
                      counterText: '',
                      contentPadding: const EdgeInsets.only(
                        left: 60,
                        right: 48,
                        top: 8,
                        bottom: 8,
                      ),
                      focusColor: primaryPink,
                      hintStyle: const TextStyle(
                        color: const Color(0xFF7C7A7A),
                        fontWeight: FontWeight.w700,
                      ),
                      hintText: 'app.mobile_name_valid'.tr(),
                      enabledBorder: _textFieldInputBorder,
                      fillColor: const Color(0xFFD9D9D9),
                      filled: true,
                      focusedBorder: _textFieldInputBorder,
                    ),
                  ),
                  Positioned(
                    top: 0,
                    left: 12,
                    bottom: 0,
                    child: Icon(
                      Icons.search,
                      color: const Color(0xFF7C7A7A),
                      size: 36,
                    ),
                  ),
                  Positioned(
                    top: 0,
                    right: 12,
                    bottom: 0,
                    child: Consumer(
                      builder: (context, ref, child) {
                        final query = ref.watch(_searchQueryProvider);
                        return Visibility(
                          visible: !query.isEmpty,
                          child: child!,
                        );
                      },
                      child: GestureDetector(
                        onTap: () {
                          FocusManager.instance.primaryFocus?.unfocus();
                          _textController.text = '';
                        },
                        child: Icon(
                          Icons.close,
                          color: const Color(0xFF7C7A7A),
                          size: 24,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 8,
              ),
              alignment: Alignment.centerLeft,
              color: const Color(0xFFEAEAEA),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'WellExp',
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: 16,
                      color: primaryUnselected,
                    ),
                  ),
                  InkWell(
                    onTap: () {
                      checkAll = !checkAll;
                      var userProvider = ref.read(widget.provider);
                      if (ref.read(widget.provider).length ==
                          ref.read(wellGiveEmployeesProvider).length) {
                        userProvider.clear();
                      } else if (checkAll) {
                        userProvider.clear();
                        userProvider
                            .addAll(ref.read(wellGiveEmployeesProvider));
                      } else {
                        userProvider.clear();
                      }
                      widget.callback(
                          WellGiveEmployeeEntity(), checkAll ? 1 : 2);
                      setState(() {});
                    },
                    child: Row(
                      children: [
                        Text(
                          ref.read(widget.provider).length ==
                                  ref.read(wellGiveEmployeesProvider).length
                              ? 'UnCheck All'
                              : checkAll
                                  ? 'UnCheck All'
                                  : 'Check All',
                          style: TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 16,
                            color: primaryUnselected,
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        ref.read(widget.provider).length ==
                                ref.read(wellGiveEmployeesProvider).length
                            ? Icon(
                                Icons.check_box_outlined,
                                color: primaryPink,
                              )
                            : checkAll
                                ? Icon(
                                    Icons.check_box_outlined,
                                    color: primaryPink,
                                  )
                                : Icon(
                                    Icons.check_box,
                                    color: Colors.white,
                                  )
                      ],
                    ),
                  )
                ],
              ),
            ),
            Expanded(
              child: Consumer(
                builder: (context, ref, child) {
                  final query =
                      ref.watch(_searchQueryProvider).toLowerCase().trim();
                  final user = ref.watch(userProvider);
                  final employees = ref
                      .watch(
                        wellGiveEmployeesProvider.select(
                          (users) => users.where(
                            (employee) =>
                                employee.id != (user?.id ?? -1) &&
                                (employee.phone.contains(query) ||
                                    employee.firstname
                                        .toLowerCase()
                                        .contains(query) ||
                                    employee.lastname
                                        .toLowerCase()
                                        .contains(query) ||
                                    '${employee.firstname.toLowerCase()} ${employee.lastname.toLowerCase()}'
                                        .contains(query)),
                          ),
                        ),
                      )
                      .toList();

                  final lastIndex = employees.length - 1;

                  return ListView.builder(
                    itemBuilder: (context, index) {
                      final user = employees[index];
                      return Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 24,
                        ),
                        child: InkWell(
                          onTap: () {
                            if (!widget.showCheckbok) {
                              FocusManager.instance.primaryFocus?.unfocus();
                              widget.onUserSelected(user);
                              Navigator.pop(context);
                            } else {
                              widget.callback(user, 0);
                              setState(() {});
                            }
                          },
                          child: Column(
                            children: [
                              if (index != lastIndex)
                                const SizedBox(
                                  height: 12,
                                ),
                              Row(
                                children: [
                                  Expanded(
                                    child: WellGiveUserSection(
                                      profileAvatarUrl: user.profile_avatar,
                                      name: user.firstname.neutralize(),
                                      lastName: user.lastname.neutralize(),
                                      mobileNo: user.phone.neutralize(),
                                      smallText: true,
                                    ),
                                  ),
                                  ref.read(widget.provider).contains(user)
                                      ? Icon(
                                          Icons.check_box,
                                          color: primaryPink,
                                        )
                                      : Icon(
                                          Icons.square_outlined,
                                          color: primaryUnselected,
                                        ),
                                ],
                              ),
                              Builder(
                                builder: (context) {
                                  if (index != lastIndex) {
                                    return Column(
                                      children: [
                                        const SizedBox(
                                          height: 12,
                                        ),
                                        _lineSeparated,
                                      ],
                                    );
                                  }
                                  return const SizedBox(
                                    height: 12,
                                  );
                                },
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                    itemCount: employees.length,
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
